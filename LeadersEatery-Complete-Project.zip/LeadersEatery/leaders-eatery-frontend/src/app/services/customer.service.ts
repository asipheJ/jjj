import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Customer {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber?: string;
}
export interface RegisterRequest {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  phoneNumber: string;
}

@Injectable({ providedIn: 'root' })
export class CustomerService {
  private readonly url = 'http://localhost:8080/api/customers';
  constructor(private http: HttpClient) {}
  register(data: RegisterRequest): Observable<Customer> {
    return this.http.post<Customer>(`${this.url}/register`, data);
  }
  login(data: { email: string; password: string }): Observable<Customer> {
    return this.http.post<Customer>(`${this.url}/login`, data);
  }
}
