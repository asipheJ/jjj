import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { FoodItem } from '../models/food-item';
import { CartItem } from '../models/cart-item';

@Injectable({ providedIn: 'root' })
export class CartService {
  private readonly subject = new BehaviorSubject<CartItem[]>([]);
  readonly items$ = this.subject.asObservable();

  add(item: FoodItem): void {
    const copy = this.subject.value.map(row => ({ ...row }));
    const existing = copy.find(row => row.foodItem.id === item.id);
    if (existing) existing.quantity += 1;
    else copy.push({ foodItem: item, quantity: 1 });
    this.subject.next(copy);
  }

  changeQuantity(id: number, quantity: number): void {
    if (quantity < 1) {
      this.remove(id);
      return;
    }
    this.subject.next(this.subject.value.map(row =>
      row.foodItem.id === id ? { ...row, quantity } : row
    ));
  }

  remove(id: number): void {
    this.subject.next(this.subject.value.filter(row => row.foodItem.id !== id));
  }

  clear(): void { this.subject.next([]); }
  count(): number { return this.subject.value.reduce((sum, row) => sum + row.quantity, 0); }
  total(): number {
    return this.subject.value.reduce((sum, row) => sum + Number(row.foodItem.price) * row.quantity, 0);
  }
}
