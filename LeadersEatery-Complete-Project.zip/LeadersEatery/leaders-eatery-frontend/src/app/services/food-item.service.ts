import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FoodItem } from '../models/food-item';

@Injectable({ providedIn: 'root' })
export class FoodItemService {
  private readonly apiUrl = 'http://localhost:8080/api/food-items';
  constructor(private http: HttpClient) {}
  getAvailableFoodItems(): Observable<FoodItem[]> {
    return this.http.get<FoodItem[]>(`${this.apiUrl}/available`);
  }
}
