export interface FoodItem {
  id: number;
  name: string;
  description: string;
  price: number;
  imageUrl: string | null;
  available: boolean;
  restaurantId: number;
  restaurantName: string;
  categoryId: number;
  categoryName: string;
}
