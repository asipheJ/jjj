import { FoodItem } from './food-item';

export interface CartItem {
  foodItem: FoodItem;
  quantity: number;
}
