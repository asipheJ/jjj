import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FoodItem } from './models/food-item';
import { CartItem } from './models/cart-item';
import { FoodItemService } from './services/food-item.service';
import { CartService } from './services/cart.service';
import { CustomerService, Customer, RegisterRequest } from './services/customer.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  foodItems: FoodItem[] = [];
  filteredItems: FoodItem[] = [];
  cartItems: CartItem[] = [];
  cartOpen = false;
  loading = true;
  menuError = '';
  searchTerm = '';
  selectedCategory = 'All';
  categories: string[] = ['All'];
  customer: Customer | null = null;
  showAccount = false;
  accountMode: 'login' | 'register' = 'register';
  accountMessage = '';
  accountError = '';
  registerForm: RegisterRequest = {
    firstName: '', lastName: '', email: '', password: '', phoneNumber: ''
  };
  loginForm = { email: '', password: '' };
  checkoutAddress = '';
  deliveryMethod = 'COURIER';
  orderMessage = '';

  constructor(
    private foodService: FoodItemService,
    private cartService: CartService,
    private customerService: CustomerService
  ) {}

  ngOnInit(): void {
    this.foodService.getAvailableFoodItems().subscribe({
      next: items => {
        this.foodItems = items;
        this.filteredItems = items;
        this.categories = ['All', ...Array.from(new Set(items.map(i => i.categoryName)))];
        this.loading = false;
      },
      error: () => {
        this.menuError = 'We could not load the menu. Please check that the backend is running.';
        this.loading = false;
      }
    });
    this.cartService.items$.subscribe(items => this.cartItems = items);
  }

  filterMenu(): void {
    const term = this.searchTerm.toLowerCase().trim();
    this.filteredItems = this.foodItems.filter(item => {
      const matchesCategory = this.selectedCategory === 'All' || item.categoryName === this.selectedCategory;
      const matchesSearch = !term || item.name.toLowerCase().includes(term) ||
        (item.description || '').toLowerCase().includes(term);
      return matchesCategory && matchesSearch;
    });
  }

  selectCategory(category: string): void {
    this.selectedCategory = category;
    this.filterMenu();
  }

  addToCart(item: FoodItem): void {
    this.cartService.add(item);
    this.cartOpen = true;
  }

  changeQuantity(item: CartItem, amount: number): void {
    this.cartService.changeQuantity(item.foodItem.id, item.quantity + amount);
  }

  removeFromCart(item: CartItem): void {
    this.cartService.remove(item.foodItem.id);
  }

  get cartCount(): number { return this.cartService.count(); }
  get cartTotal(): number { return this.cartService.total(); }

  register(): void {
    this.accountError = '';
    this.accountMessage = '';
    this.customerService.register(this.registerForm).subscribe({
      next: customer => {
        this.customer = customer;
        this.accountMessage = `Welcome, ${customer.firstName}! Your account has been created.`;
        this.showAccount = false;
      },
      error: err => this.accountError = err.error?.message || 'Registration failed. Check the details and try again.'
    });
  }

  login(): void {
    this.accountError = '';
    this.accountMessage = '';
    this.customerService.login(this.loginForm).subscribe({
      next: customer => {
        this.customer = customer;
        this.showAccount = false;
      },
      error: err => this.accountError = err.error?.message || 'Login failed. Check your email and password.'
    });
  }

  logout(): void { this.customer = null; }

  placeOrder(): void {
    if (!this.customer) {
      this.accountMode = 'login';
      this.showAccount = true;
      this.accountError = 'Please log in before placing an order.';
      return;
    }
    if (!this.cartItems.length) return;
    if (this.deliveryMethod === 'COURIER' && !this.checkoutAddress.trim()) {
      this.orderMessage = 'Please enter your delivery address.';
      return;
    }
    const request = {
      customerId: this.customer.id,
      deliveryMethod: this.deliveryMethod,
      deliveryAddress: this.deliveryMethod === 'COLLECTION' ? 'Library/restaurant collection' : this.checkoutAddress,
      items: this.cartItems.map(row => ({ foodItemId: row.foodItem.id, quantity: row.quantity }))
    };
    // Order endpoint is intentionally called here; it recalculates prices on the server.
    fetch('http://localhost:8080/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request)
    }).then(async response => {
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || 'Could not place order');
      this.orderMessage = `Order #${result.id} placed successfully. Total: R${Number(result.total).toFixed(2)}.`;
      this.cartService.clear();
      this.cartOpen = false;
    }).catch(error => this.orderMessage = error.message);
  }
}
