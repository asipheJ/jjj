# Leader's Eatery — Full-Stack Food Delivery Application

A beginner-friendly full-stack starter project using:
- Java 11
- Spring Boot 2.7.18 (not Spring Boot 3)
- Maven
- MySQL + Spring Data JPA / Hibernate
- Angular 22 standalone frontend
- REST API

## Project structure
- `leaders-eatery-backend/` — Spring Boot REST API
- `leaders-eatery-frontend/` — Angular customer-facing app

## Prerequisites
- JDK 11
- Maven 3.9+
- MySQL Server 8+
- Node.js 24 and npm
- Angular CLI 22

## 1. Database
Start MySQL and execute in MySQL Workbench:

```sql
CREATE DATABASE IF NOT EXISTS leaders_eatery_db;
```

Hibernate creates/updates tables from Java entity classes on backend startup. You do not need to create application tables manually.

## 2. Configure backend
Open `leaders-eatery-backend/src/main/resources/application.properties`.
Set `spring.datasource.username` and `spring.datasource.password` to your local MySQL credentials.

## 3. Start backend
From the `leaders-eatery-backend` directory:

```powershell
mvn clean test
mvn spring-boot:run
```

Backend: `http://localhost:8080`

Useful endpoints:
- `GET http://localhost:8080/api/categories`
- `GET http://localhost:8080/api/restaurants`
- `GET http://localhost:8080/api/food-items`
- `GET http://localhost:8080/api/food-items/available`
- `POST http://localhost:8080/api/customers/register`
- `POST http://localhost:8080/api/customers/login`
- `POST http://localhost:8080/api/orders`

## 4. Seed sample data
Once the backend is running, open a second PowerShell terminal in the backend folder and run:

```powershell
.\seed-sample-data.ps1
```

This creates sample categories, a restaurant, and food items through the REST API. The script is safe to re-run for the supplied sample names.

## 5. Start Angular
Open a second terminal in `leaders-eatery-frontend`:

```powershell
npm install
ng serve
```

Open `http://localhost:4200`.

## 6. Customer workflow
1. Register an account.
2. Browse menu items.
3. Add items to the cart and adjust quantities.
4. Enter delivery details and place an order.
5. View order confirmation.

## Notes / next production-hardening tasks
- The sample login endpoint verifies BCrypt passwords but does not issue JWT tokens. Add JWT authentication and role-based authorization before public deployment.
- Admin CRUD endpoints are intentionally a development starter and are not protected yet.
- Use environment variables or a secrets manager for database credentials in production.
- Add payment-provider integration only after selecting a provider and implementing its security requirements.
