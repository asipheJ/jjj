$base = "http://localhost:8080/api"

$categories = Invoke-RestMethod -Uri "$base/categories"
if (-not ($categories | Where-Object { $_.name -eq "Burgers" })) {
    Invoke-RestMethod -Uri "$base/categories" -Method POST -ContentType "application/json" -Body (@{
        name = "Burgers"; description = "Freshly prepared burgers"; active = $true
    } | ConvertTo-Json) | Out-Null
}
if (-not ($categories | Where-Object { $_.name -eq "Sides" })) {
    Invoke-RestMethod -Uri "$base/categories" -Method POST -ContentType "application/json" -Body (@{
        name = "Sides"; description = "Tasty sides and snacks"; active = $true
    } | ConvertTo-Json) | Out-Null
}

$restaurants = Invoke-RestMethod -Uri "$base/restaurants"
if (-not ($restaurants | Where-Object { $_.name -eq "Leaders Burger House" })) {
    Invoke-RestMethod -Uri "$base/restaurants" -Method POST -ContentType "application/json" -Body (@{
        name = "Leaders Burger House"
        description = "Fresh, satisfying meals made to order."
        address = "Pretoria, South Africa"
        phoneNumber = "0120000000"
        imageUrl = ""
        active = $true
    } | ConvertTo-Json) | Out-Null
}

$categories = Invoke-RestMethod -Uri "$base/categories"
$restaurants = Invoke-RestMethod -Uri "$base/restaurants"
$burger = $categories | Where-Object { $_.name -eq "Burgers" } | Select-Object -First 1
$sides = $categories | Where-Object { $_.name -eq "Sides" } | Select-Object -First 1
$restaurant = $restaurants | Where-Object { $_.name -eq "Leaders Burger House" } | Select-Object -First 1

$foods = Invoke-RestMethod -Uri "$base/food-items"
$sampleFoods = @(
    @{ name="Classic Beef Burger"; description="Juicy beef patty, lettuce, tomato and our house sauce."; price=85.00; imageUrl="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800"; available=$true; restaurantId=$restaurant.id; categoryId=$burger.id },
    @{ name="Crispy Chicken Burger"; description="Golden crispy chicken with fresh lettuce and creamy sauce."; price=79.00; imageUrl="https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=800"; available=$true; restaurantId=$restaurant.id; categoryId=$burger.id },
    @{ name="Golden Chips"; description="Crispy golden potato chips."; price=35.00; imageUrl="https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=800"; available=$true; restaurantId=$restaurant.id; categoryId=$sides.id }
)
foreach ($food in $sampleFoods) {
    if (-not ($foods | Where-Object { $_.name -eq $food.name })) {
        Invoke-RestMethod -Uri "$base/food-items" -Method POST -ContentType "application/json" -Body ($food | ConvertTo-Json) | Out-Null
    }
}
Write-Host "Sample categories, restaurant and food items are ready." -ForegroundColor Green
