package com.leaderseatery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeadersEateryBackendApplicationTests {
    @Test
    void contextLoads() {
    }
}
