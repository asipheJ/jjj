package com.leaderseatery.dto;

import java.util.List;

public class OrderRequest {
    private Long customerId;
    private String deliveryMethod;
    private String deliveryAddress;
    private List<Line> items;

    public static class Line {
        private Long foodItemId;
        private Integer quantity;
        public Long getFoodItemId() { return foodItemId; }
        public void setFoodItemId(Long foodItemId) { this.foodItemId = foodItemId; }
        public Integer getQuantity() { return quantity; }
        public void setQuantity(Integer quantity) { this.quantity = quantity; }
    }
    public Long getCustomerId() { return customerId; }
    public void setCustomerId(Long customerId) { this.customerId = customerId; }
    public String getDeliveryMethod() { return deliveryMethod; }
    public void setDeliveryMethod(String deliveryMethod) { this.deliveryMethod = deliveryMethod; }
    public String getDeliveryAddress() { return deliveryAddress; }
    public void setDeliveryAddress(String deliveryAddress) { this.deliveryAddress = deliveryAddress; }
    public List<Line> getItems() { return items; }
    public void setItems(List<Line> items) { this.items = items; }
}
