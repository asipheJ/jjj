package com.leaderseatery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeadersEateryBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(LeadersEateryBackendApplication.class, args);
    }
}
