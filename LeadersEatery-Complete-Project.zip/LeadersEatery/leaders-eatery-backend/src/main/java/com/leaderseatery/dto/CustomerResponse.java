package com.leaderseatery.dto;

import com.leaderseatery.entity.Customer;

public class CustomerResponse {
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;

    public CustomerResponse(Customer c) {
        id = c.getId(); firstName = c.getFirstName(); lastName = c.getLastName();
        email = c.getEmail(); phoneNumber = c.getPhoneNumber();
    }
    public Long getId() { return id; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getEmail() { return email; }
    public String getPhoneNumber() { return phoneNumber; }
}
