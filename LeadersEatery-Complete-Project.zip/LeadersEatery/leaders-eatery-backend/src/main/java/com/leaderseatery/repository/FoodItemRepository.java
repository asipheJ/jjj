package com.leaderseatery.repository;

import com.leaderseatery.entity.FoodItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FoodItemRepository extends JpaRepository<FoodItem, Long> {
    List<FoodItem> findByAvailableTrue();
    List<FoodItem> findByCategoryId(Long categoryId);
    List<FoodItem> findByRestaurantId(Long restaurantId);
}
