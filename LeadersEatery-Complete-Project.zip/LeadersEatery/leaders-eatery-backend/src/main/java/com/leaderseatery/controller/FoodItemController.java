package com.leaderseatery.controller;

import com.leaderseatery.dto.FoodItemResponse;
import com.leaderseatery.entity.*;
import com.leaderseatery.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/food-items")
public class FoodItemController {
    private final FoodItemRepository foods;
    private final RestaurantRepository restaurants;
    private final FoodCategoryRepository categories;

    public FoodItemController(FoodItemRepository foods, RestaurantRepository restaurants, FoodCategoryRepository categories) {
        this.foods = foods; this.restaurants = restaurants; this.categories = categories;
    }

    @GetMapping public List<FoodItemResponse> all() {
        return foods.findAll().stream().map(FoodItemResponse::new).collect(Collectors.toList());
    }
    @GetMapping("/available") public List<FoodItemResponse> available() {
        return foods.findByAvailableTrue().stream().map(FoodItemResponse::new).collect(Collectors.toList());
    }
    @GetMapping("/{id}") public FoodItemResponse one(@PathVariable Long id) {
        return new FoodItemResponse(foods.findById(id).orElseThrow(() -> new IllegalArgumentException("Food item not found")));
    }
    @GetMapping("/category/{id}") public List<FoodItemResponse> byCategory(@PathVariable Long id) {
        return foods.findByCategoryId(id).stream().map(FoodItemResponse::new).collect(Collectors.toList());
    }
    @GetMapping("/restaurant/{id}") public List<FoodItemResponse> byRestaurant(@PathVariable Long id) {
        return foods.findByRestaurantId(id).stream().map(FoodItemResponse::new).collect(Collectors.toList());
    }
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public FoodItemResponse create(@RequestBody FoodItemInput input) {
        FoodItem f = new FoodItem();
        apply(f, input);
        return new FoodItemResponse(foods.save(f));
    }
    @PutMapping("/{id}") public FoodItemResponse update(@PathVariable Long id, @RequestBody FoodItemInput input) {
        FoodItem f = foods.findById(id).orElseThrow(() -> new IllegalArgumentException("Food item not found"));
        apply(f, input);
        return new FoodItemResponse(foods.save(f));
    }
    @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable Long id) { foods.deleteById(id); }

    private void apply(FoodItem f, FoodItemInput i) {
        f.setName(i.name); f.setDescription(i.description); f.setPrice(i.price);
        f.setImageUrl(i.imageUrl); f.setAvailable(i.available);
        f.setRestaurant(restaurants.findById(i.restaurantId).orElseThrow(() -> new IllegalArgumentException("Restaurant not found")));
        f.setCategory(categories.findById(i.categoryId).orElseThrow(() -> new IllegalArgumentException("Category not found")));
    }
    public static class FoodItemInput {
        public String name;
        public String description;
        public BigDecimal price;
        public String imageUrl;
        public boolean available = true;
        public Long restaurantId;
        public Long categoryId;
    }
}
