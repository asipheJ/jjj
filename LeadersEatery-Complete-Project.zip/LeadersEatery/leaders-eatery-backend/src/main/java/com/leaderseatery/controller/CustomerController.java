package com.leaderseatery.controller;

import com.leaderseatery.dto.*;
import com.leaderseatery.entity.Customer;
import com.leaderseatery.repository.CustomerRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.Map;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {
    private final CustomerRepository customers;
    private final PasswordEncoder encoder;

    public CustomerController(CustomerRepository customers, PasswordEncoder encoder) {
        this.customers = customers; this.encoder = encoder;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegistrationRequest request) {
        if (customers.findByEmail(request.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("message", "Email already registered"));
        }
        Customer c = new Customer();
        c.setFirstName(request.getFirstName());
        c.setLastName(request.getLastName());
        c.setEmail(request.getEmail().toLowerCase().trim());
        c.setPhoneNumber(request.getPhoneNumber());
        c.setPasswordHash(encoder.encode(request.getPassword()));
        return ResponseEntity.status(HttpStatus.CREATED).body(new CustomerResponse(customers.save(c)));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest request) {
        return customers.findByEmail(request.getEmail().toLowerCase().trim())
                .filter(c -> encoder.matches(request.getPassword(), c.getPasswordHash()))
                .<ResponseEntity<?>>map(c -> ResponseEntity.ok(new CustomerResponse(c)))
                .orElseGet(() -> ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of("message", "Invalid email or password")));
    }
}
