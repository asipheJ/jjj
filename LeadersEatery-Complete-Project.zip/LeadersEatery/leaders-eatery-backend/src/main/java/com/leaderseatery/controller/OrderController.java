package com.leaderseatery.controller;

import com.leaderseatery.dto.OrderRequest;
import com.leaderseatery.entity.*;
import com.leaderseatery.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    private final CustomerOrderRepository orders;
    private final CustomerRepository customers;
    private final FoodItemRepository foods;

    public OrderController(CustomerOrderRepository orders, CustomerRepository customers, FoodItemRepository foods) {
        this.orders = orders; this.customers = customers; this.foods = foods;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Transactional
    public Map<String, Object> place(@RequestBody OrderRequest request) {
        if (request.getItems() == null || request.getItems().isEmpty()) throw new IllegalArgumentException("Order must contain items");
        Customer customer = customers.findById(request.getCustomerId()).orElseThrow(() -> new IllegalArgumentException("Customer not found"));
        CustomerOrder order = new CustomerOrder();
        order.setCustomer(customer);
        order.setDeliveryMethod(request.getDeliveryMethod());
        order.setDeliveryAddress(request.getDeliveryAddress());
        BigDecimal total = BigDecimal.ZERO;
        for (OrderRequest.Line line : request.getItems()) {
            if (line.getQuantity() == null || line.getQuantity() < 1) throw new IllegalArgumentException("Quantity must be at least 1");
            FoodItem food = foods.findById(line.getFoodItemId()).orElseThrow(() -> new IllegalArgumentException("Food item not found"));
            if (!food.isAvailable()) throw new IllegalArgumentException(food.getName() + " is unavailable");
            OrderItem item = new OrderItem();
            item.setFoodItem(food);
            item.setQuantity(line.getQuantity());
            item.setUnitPrice(food.getPrice());
            order.addItem(item);
            total = total.add(food.getPrice().multiply(BigDecimal.valueOf(line.getQuantity())));
        }
        order.setTotal(total);
        CustomerOrder saved = orders.save(order);
        return Map.of("id", saved.getId(), "total", saved.getTotal(), "status", saved.getStatus(), "message", "Order placed successfully");
    }

    @GetMapping("/customer/{customerId}")
    public List<CustomerOrder> byCustomer(@PathVariable Long customerId) {
        return orders.findByCustomerIdOrderByCreatedAtDesc(customerId);
    }
}
