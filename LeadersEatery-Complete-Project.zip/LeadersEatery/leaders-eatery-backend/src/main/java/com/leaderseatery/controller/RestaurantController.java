package com.leaderseatery.controller;

import com.leaderseatery.entity.Restaurant;
import com.leaderseatery.repository.RestaurantRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/restaurants")
public class RestaurantController {
    private final RestaurantRepository repository;
    public RestaurantController(RestaurantRepository repository) { this.repository = repository; }
    @GetMapping public List<Restaurant> all() { return repository.findAll(); }
    @GetMapping("/active") public List<Restaurant> active() { return repository.findByActiveTrue(); }
    @PostMapping public Restaurant create(@RequestBody Restaurant restaurant) { restaurant.setId(null); return repository.save(restaurant); }
    @PutMapping("/{id}") public Restaurant update(@PathVariable Long id, @RequestBody Restaurant input) {
        Restaurant r = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Restaurant not found"));
        r.setName(input.getName()); r.setDescription(input.getDescription()); r.setAddress(input.getAddress());
        r.setPhoneNumber(input.getPhoneNumber()); r.setImageUrl(input.getImageUrl()); r.setActive(input.isActive());
        return repository.save(r);
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id) { repository.deleteById(id); }
}
