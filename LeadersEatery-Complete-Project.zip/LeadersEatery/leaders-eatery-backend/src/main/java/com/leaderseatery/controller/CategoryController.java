package com.leaderseatery.controller;

import com.leaderseatery.entity.FoodCategory;
import com.leaderseatery.repository.FoodCategoryRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {
    private final FoodCategoryRepository repository;
    public CategoryController(FoodCategoryRepository repository) { this.repository = repository; }
    @GetMapping public List<FoodCategory> all() { return repository.findAll(); }
    @GetMapping("/active") public List<FoodCategory> active() { return repository.findByActiveTrue(); }
    @PostMapping public FoodCategory create(@RequestBody FoodCategory category) { category.setId(null); return repository.save(category); }
    @PutMapping("/{id}") public FoodCategory update(@PathVariable Long id, @RequestBody FoodCategory input) {
        FoodCategory c = repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Category not found"));
        c.setName(input.getName()); c.setDescription(input.getDescription()); c.setActive(input.isActive()); return repository.save(c);
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id) { repository.deleteById(id); }
}
