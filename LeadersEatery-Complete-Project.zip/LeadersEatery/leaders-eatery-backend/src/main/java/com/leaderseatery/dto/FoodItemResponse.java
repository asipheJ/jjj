package com.leaderseatery.dto;

import com.leaderseatery.entity.FoodItem;
import java.math.BigDecimal;

public class FoodItemResponse {
    private Long id;
    private String name;
    private String description;
    private BigDecimal price;
    private String imageUrl;
    private boolean available;
    private Long restaurantId;
    private String restaurantName;
    private Long categoryId;
    private String categoryName;

    public FoodItemResponse(FoodItem item) {
        id = item.getId();
        name = item.getName();
        description = item.getDescription();
        price = item.getPrice();
        imageUrl = item.getImageUrl();
        available = item.isAvailable();
        restaurantId = item.getRestaurant().getId();
        restaurantName = item.getRestaurant().getName();
        categoryId = item.getCategory().getId();
        categoryName = item.getCategory().getName();
    }
    public Long getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public BigDecimal getPrice() { return price; }
    public String getImageUrl() { return imageUrl; }
    public boolean isAvailable() { return available; }
    public Long getRestaurantId() { return restaurantId; }
    public String getRestaurantName() { return restaurantName; }
    public Long getCategoryId() { return categoryId; }
    public String getCategoryName() { return categoryName; }
}
